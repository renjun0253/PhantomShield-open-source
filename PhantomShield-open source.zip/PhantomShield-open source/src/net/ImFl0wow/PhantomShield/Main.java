public class Main
{
    public String name = "PhantomShield";
    public String version = "X";
    public String UN = "ImFl0wow";

    public static void Main(String[] args) {
        System.out.println("phantom-shield-x Loading!!!");
    }
}